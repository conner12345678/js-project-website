// This is the navBar of the website
const navBar = document.createElement('div')
navBar.innerHTML = `<div id='inner'><a href='homepage.html' id='dInner'>Home</a></div>
                    <div id='inner2'><a href='gallerypage.html' id='dInner2'>Gallery</a></div>
                    <div id='inner3'><a href='about_me.html' id='dInner3'>About me</a></div>`
navBar.style.backgroundColor = 'black'
navBar.style.float = 'right'
navBar.style.width = '100%'
navBar.style.textAlign = 'center'
navBar.style.position = 'sticky'
navBar.style.top = '8px'
document.body.appendChild(navBar)
document.getElementById('inner').style.backgroundColor = 'black'
document.getElementById('inner').style.margin = '5px'
document.getElementById('inner').style.padding = '10px'
document.getElementById('inner').style.overflow = 'hidden'
document.getElementById('inner').style.width = '17%'
document.getElementById('inner').style.float = 'left'
document.getElementById('inner2').style.backgroundColor = 'black'
document.getElementById('inner2').style.margin = '5px'
document.getElementById('inner2').style.padding = '10px'
document.getElementById('inner2').style.overflow = 'hidden'
document.getElementById('inner2').style.width = '17%'
document.getElementById('inner2').style.float = 'left'
document.getElementById('inner3').style.backgroundColor = 'black'
document.getElementById('inner3').style.margin = '5px'
document.getElementById('inner3').style.padding = '10px'
document.getElementById('inner3').style.overflow = 'hidden'
document.getElementById('inner3').style.width = '17%'
document.getElementById('inner3').style.float = 'left'
document.getElementById('inner4').style.backgroundColor = 'black'
document.getElementById('inner4').style.margin = '5px'
document.getElementById('inner4').style.padding = '10px'
document.getElementById('inner4').style.overflow = 'hidden'
document.getElementById('inner4').style.width = '17%'
document.getElementById('inner4').style.float = 'left'
//End of navBar


const title = document.createElement('h1')
const paragraph = document.createElement('p')
const paragraph2 = document.createElement('p')
const paragraph3 = document.createElement('p')

title.innerHTML = 'Hello, welcome to my website!'
paragraph.innerHTML = 'Hello, welcome to the website! this website was made in javascrypt almost compleatly. Including this paragraph that you are reading right now!'
paragraph2.innerHTML = 'space'
paragraph3.innerHTML = 'There is not much more to this website but the fact that it was made in javascript, however the website is fully functional'

title.style.textAlign = 'center'
paragraph.style.textAlign = 'center'
document.body.style.backgroundColor = 'orange'
paragraph2.style.textAlign = 'center'
paragraph2.style.color = 'orange'
paragraph3.style.textAlign = 'center'

document.body.appendChild(title)
document.body.appendChild(paragraph)
document.body.appendChild(paragraph2)
document.body.appendChild(paragraph3)