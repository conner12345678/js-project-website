document.body.style.backgroundColor = 'orange'

// This is the navBar of the website
const navBar = document.createElement('div')
navBar.innerHTML = `<div id='inner'><a href='homepage.html' id='dInner'>Home</a></div>
                    <div id='inner2'><a href='gallerypage.html' id='dInner2'>Gallery</a></div>
                    <div id='inner3'><a href='about_me.html' id='dInner3'>About me</a></div>`
navBar.style.backgroundColor = 'black'
navBar.style.zIndex = 3
navBar.style.float = 'right'
navBar.style.width = '100%'
navBar.style.textAlign = 'center'
navBar.style.position = 'sticky'
navBar.style.top = '8px'
document.body.appendChild(navBar)
document.getElementById('inner').style.backgroundColor = 'black'
document.getElementById('inner').style.margin = '5px'
document.getElementById('inner').style.padding = '10px'
document.getElementById('inner').style.overflow = 'hidden'
document.getElementById('inner').style.width = '17%'
document.getElementById('inner').style.float = 'left'
document.getElementById('inner2').style.backgroundColor = 'black'
document.getElementById('inner2').style.margin = '5px'
document.getElementById('inner2').style.padding = '10px'
document.getElementById('inner2').style.overflow = 'hidden'
document.getElementById('inner2').style.width = '17%'
document.getElementById('inner2').style.float = 'left'
document.getElementById('inner3').style.backgroundColor = 'black'
document.getElementById('inner3').style.margin = '5px'
document.getElementById('inner3').style.padding = '10px'
document.getElementById('inner3').style.overflow = 'hidden'
document.getElementById('inner3').style.width = '17%'
document.getElementById('inner3').style.float = 'left'
document.getElementById('inner4').style.backgroundColor = 'black'
document.getElementById('inner4').style.margin = '5px'
document.getElementById('inner4').style.padding = '10px'
document.getElementById('inner4').style.overflow = 'hidden'
document.getElementById('inner4').style.width = '17%'
document.getElementById('inner4').style.float = 'left'
//End of navBar

//Paragraph one
const current = document.createElement('h1')
current.innerHTML = "Current life"
current.style.textAlign = 'center'
document.body.appendChild(current)
const para1 = document.createElement('p')
para1.innerHTML = "What I am doing currently is going to my third year of high school, my first year of west-mec, and I am working my first part time job at subway. Currently my grades at high school are going up, and I am trying to bring my grades at west-mec up. As far as the part time job goes, I know what I need to know to get through the job with mostly ease."
para1.style.textAlign = 'center'
document.body.appendChild(para1)
current.style.position = 'relative'
para1.style.position = 'relative'
//End of paragraph 1

//Paragraph 2
const plans = document.createElement('h1')
plans.innerHTML = "What I plan to do"
plans.style.textAlign = 'center'
document.body.appendChild(plans)
const para2 = document.createElement('p')
para2.innerHTML = "What I want to do in the future is use what I am learning from west-mec to go into the website development industry. Another thing that I want to do is make my own game, however currently I have no progress on that. The game that I want to work on is a horror game based around an abandoned underground water park. Here are some images that I made with AI that I thought looked pretty cool:"
para2.style.textAlign = 'center'
document.body.appendChild(para2)
const imageContainer = document.createElement('div')
imageContainer.innerHTML = `<img id='image1' src='./images/abandond_water.png' alt='' onclick="resize('./images/abandond_water.png')">
                            <img id='image2' src='./images/abandond_water2.jpg' alt='' onclick="resize('./images/abandond_water2.jpg')">
                            <img id='image3' src='./images/abandond_water3.jpg' alt='' onclick="resize('./images/abandond_water3.jpg')">
                            <img id='image4' src='./images/abandond_water4.jpg' alt='' onclick="resize('./images/abandond_water4.jpg')">`
imageContainer.style.width = '100%'
imageContainer.style.height = '100%'
plans.style.position = 'relative'
para2.style.position = 'relative'
imageContainer.style.position = 'relative'
document.body.appendChild(imageContainer)
document.getElementById('image1').style.width = '49%'
document.getElementById('image1').style.height = '49%'
document.getElementById('image2').style.width = '49%'
document.getElementById('image2').style.height = '49%'
document.getElementById('image3').style.width = '49%'
document.getElementById('image3').style.height = '49%'
document.getElementById('image4').style.width = '49%'
document.getElementById('image4').style.height = '49%'
//End paragraph 2

//Making images resizable
const newImage = document.createElement('div')
const resize = (text) => {
    newImage.innerHTML = "<img id='newImg' src='" + text + "' alt'' onclick='remake()'>"
    newImage.style.visibility = 'visible'
    newImage.style.width = '100%'
    newImage.style.height = '100%'
    newImage.style.position = 'absolute'
    newImage.style.top = '8px'
    document.body.appendChild(newImage)
    document.getElementById('newImg').style.width = '100%'
    document.getElementById('newImg').style.height = '100%'
    current.style.visibility = 'hidden'
    para1.style.visibility = 'hidden'
    plans.style.visibility = 'hidden'
    para2.style.visibility = 'hidden'
    imageContainer.style.visibility = 'hidden'
}
const remake = () => {
    newImage.style.visibility = 'hidden'
    current.style.visibility = 'visible'
    para1.style.visibility = 'visible'
    plans.style.visibility = 'visible'
    para2.style.visibility = 'visible'
    imageContainer.style.visibility = 'visible'
}