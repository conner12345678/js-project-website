document.body.style.backgroundColor = 'orange'


// This is the navBar of the website
const navBar = document.createElement('div')
navBar.innerHTML = `<div id='inner'><a href='homepage.html' id='dInner'>Home</a></div>
                    <div id='inner2'><a href='gallerypage.html' id='dInner2'>Gallery</a></div>
                    <div id='inner3'><a href='about_me.html' id='dInner3'>About me</a></div>`
navBar.style.backgroundColor = 'black'
navBar.style.float = 'right'
navBar.style.width = '100%'
navBar.style.textAlign = 'center'
navBar.style.position = 'sticky'
navBar.style.top = '8px'
navBar.style.zIndex = 3
document.body.appendChild(navBar)
document.getElementById('inner').style.backgroundColor = 'black'
document.getElementById('inner').style.margin = '5px'
document.getElementById('inner').style.padding = '10px'
document.getElementById('inner').style.overflow = 'hidden'
document.getElementById('inner').style.width = '17%'
document.getElementById('inner').style.float = 'left'
document.getElementById('inner2').style.backgroundColor = 'black'
document.getElementById('inner2').style.margin = '5px'
document.getElementById('inner2').style.padding = '10px'
document.getElementById('inner2').style.overflow = 'hidden'
document.getElementById('inner2').style.width = '17%'
document.getElementById('inner2').style.float = 'left'
document.getElementById('inner3').style.backgroundColor = 'black'
document.getElementById('inner3').style.margin = '5px'
document.getElementById('inner3').style.padding = '10px'
document.getElementById('inner3').style.overflow = 'hidden'
document.getElementById('inner3').style.width = '17%'
document.getElementById('inner3').style.float = 'left'
document.getElementById('inner4').style.backgroundColor = 'black'
document.getElementById('inner4').style.margin = '5px'
document.getElementById('inner4').style.padding = '10px'
document.getElementById('inner4').style.overflow = 'hidden'
document.getElementById('inner4').style.width = '17%'
document.getElementById('inner4').style.float = 'left'
//End of navBar

//This is the gallery of images
const imageContainer = document.createElement('div')
imageContainer.innerHTML = `<img id='image' src="./images/javaImage1.jpg" alt="" onclick="resize('./images/javaImage1.jpg')">
                            <img id='image2' src="./images/javaImage2.jpg" alt="" onclick="resize('./images/javaImage2.jpg')">
                            <img id='image3' src="./images/javaImage3.jpg" alt="" onclick="resize('./images/javaImage3.jpg')">
                            <img id='image4' src="./images/javaImage4.jpg" alt="" onclick="resize('./images/javaImage4.jpg')">`
imageContainer.style.width = '100%'
imageContainer.style.height = '100%'
imageContainer.style.textAlign = 'center'
imageContainer.style.position = 'relative'
document.body.appendChild(imageContainer)
document.getElementById('image').style.width = '49%'
document.getElementById('image').style.height = '49%'
document.getElementById('image2').style.width = '49%'
document.getElementById('image2').style.height = '49%'
document.getElementById('image3').style.width = '49%'
document.getElementById('image3').style.height = '49%'
document.getElementById('image4').style.width = '49%'
document.getElementById('image4').style.height = '49%'
//End of code for the gallery of images

//Making the images resized
const newImage = document.createElement('div')
const resize = (text) => {
    newImage.style.visibility = 'visible'
    newImage.innerHTML = "<img id='resizedImg' src='" + text + "' alt='' onclick='returner()'>"
    imageContainer.style.visibility = 'hidden'
    newImage.style.position = 'absolute'
    newImage.style.top = '8px'
    newImage.style.width = '100%'
    newImage.style.height = '100%'
    document.body.appendChild(newImage)
    document.getElementById('resizedImg').style.width = '100%'
    document.getElementById('resizedImg').style.height = '100%'
}
const returner = () => {
    newImage.remove()
    imageContainer.style.visibility = 'visible'
}